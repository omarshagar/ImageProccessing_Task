function [x] =imageToVector(img)

%[x]=extractLBPFeatures(rgb2gray(img));
%figure ;imshow(img);
%hold on;
%plot(y);
%x=x';
%size(x)
x=imhist(img(:,:,1));
x=[ x ;imhist(img(:,:,2))];
x=[ x ;imhist(img(:,:,3))];
end