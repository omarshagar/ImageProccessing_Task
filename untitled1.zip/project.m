clear all; 
close all;

allimages=init();

im=imread('all-back.jpg');
%v=valueOfImage(imread('200-back.jpg'),allimages);
%v
%h=cutImageandcalc(im,allimages);
%h
rrs=Cut2(im,allimages);
rrs